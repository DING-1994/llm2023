import gym
from gym import error, spaces, utils
from gym.utils import seeding
import csv
import networkx as nx
import numpy as np
import matplotlib.pyplot as plt
import sys
import copy
import itertools
from hrs_hot_file import hrs_hot_func
from fov_wrapper import neighbor_filter_obs
import os
sys.path.append(os.path.join(os.path.dirname(__file__), ''))
from EE_map import MapMake




class VrpEnv(gym.Env):
  metadata = {'render.modes': ['human']}

  def __init__(self,agent_num,base_nodes,speed,start_ori_array,goal_array,visu_delay,m,round_trip,state_repre_flag,map_name="map_3x3"):
    #pass parameters
    self.agent_num=agent_num
    self.n_agents=agent_num # for epymarl
    self.speed=speed
    self.colli_distan_value=0.1
    self.r_flag=0
    self.visu_delay=visu_delay
    self.flag_indicate=0
    self.m=m
    self.episode_account=0
    self.state_repre_flag=state_repre_flag

    #create ee_env and pass self.variable
    self.ee_env=MapMake(self.agent_num,start_ori_array,goal_array,map_name)
    self.pos=self.ee_env.pos
    self.start_ori_array=self.ee_env.start_ori_array
    self.goal_array=self.ee_env.goal_array
    self.G=self.ee_env.G
    self.edge_labels=self.ee_env.edge_labels

    #create gym-like mdp elements
    self.action_space = gym.spaces.Tuple(tuple([gym.spaces.Discrete(len(self.G.nodes))] * self.agent_num))
    obs_box=gym.spaces.Box(np.array([0,0,0,0]), np.array([100,100,len(self.G.nodes),len(self.G.nodes)]))
    if self.state_repre_flag=='heu_onehot' or self.state_repre_flag=='heu_onehot_fov':
    #if self.state_repre_flag=='heu_onehot':
      obs_box=gym.spaces.Box(np.array([0] *len(self.G.nodes)), np.array([100]*len(self.G.nodes)))
    elif self.state_repre_flag=='onehot' or self.state_repre_flag=='onehot_fov':
    #elif self.state_repre_flag=='onehot':
      obs_box=gym.spaces.Box(np.array([0] *len(self.G.nodes)*2), np.array([100]*len(self.G.nodes)*2))
    
    #print("obs_box",obs_box)

    self.observation_space = gym.spaces.Tuple(tuple([obs_box] * self.agent_num))
    self.n_actions = self.action_space[0].n

  def get_obs(self, ):
      return self.obs

  def get_state(self,):
      return self.s

  def get_avail_agent_actions(self,agent_id, n_actions):
      #avail_actions=self.ee_env.get_avail_action_fun(self.obs[agent_id], self.joint_action_old[agent_id],self.goal_array[agent_id])
      avail_actions=self.ee_env.get_avail_action_fun(self.obs[agent_id], self.current_goal[agent_id], self.goal_array[agent_id])
      
      avail_actions_one_hot=np.zeros(n_actions)
      avail_actions_one_hot[avail_actions ]=1
      return avail_actions_one_hot,avail_actions

  def reset(self):
    # if goal and start are not assigned, randomly generate every episode    
    self.start_ori_array=copy.deepcopy(self.ee_env.input_start_ori_array)
    self.goal_array=copy.deepcopy(self.ee_env.input_goal_array)
    print("self.start_ori_array",self.start_ori_array)
    if self.start_ori_array==[]:
      self.ee_env.random_start()
      self.start_ori_array=self.ee_env.start_ori_array
    if self.goal_array==[]:
      self.ee_env.random_goal()
      self.goal_array=self.ee_env.goal_array
    print("self.start_ori_array after",self.start_ori_array)

    #initialize obs
    self.obs=tuple( np.array([ self.pos[ self.start_ori_array[i] ][0], self.pos[ self.start_ori_array[i] ][1] ,self.start_ori_array[i], self.goal_array[i] ], dtype='float32') for i in range(self.agent_num) )
    self.obs_current_chache=copy.deepcopy(self.obs)# used for calculating reward
    
    #initialize obs_one-hot
    self.obs_onehot=np.zeros( ( self.agent_num,  len(list(self.G.nodes()))*2   ) )
    for i in range(self.agent_num):
      self.obs_onehot[i][int(self.start_ori_array[i])] = 1 #current position
      self.obs_onehot[i][int(self.goal_array[i])+ len(list(self.G.nodes())) ] = 1 #current goal
    #self.obs_onehot_current_chache=copy.deepcopy(self.obs_onehot)


    self.current_start = self.start_ori_array # [0,1]
    self.current_goal  = [ None for i in range(self.agent_num)]
    self.terminated    = [ False for i in range(self.agent_num)]

    self.reach_account=0
    self.step_account=0
    self.episode_account+=1
    print('Environment reset obs: \n', self.obs)
    if self.state_repre_flag=='coordinate':
      return self.obs
    elif self.state_repre_flag=='onehot':
      print('onehot',self.obs_onehot)
      return self.obs_onehot
    elif self.state_repre_flag=='heu_onehot':
      print('heu_onehot',hrs_hot_func(self, self.obs) )
      return hrs_hot_func(self, self.obs)
    
    elif self.state_repre_flag=='onehot_fov':
      onehot_fov_v=neighbor_filter_obs(self,self.state_repre_flag)
      print('onehot_fov_v', onehot_fov_v)
      return onehot_fov_v
    elif self.state_repre_flag=='heu_onehot_fov':
      heu_onehot_fov_v=neighbor_filter_obs(self,self.state_repre_flag)
      print('heu_onehot_fov_v', heu_onehot_fov_v)
      return heu_onehot_fov_v
    

  def step(self,joint_action):
    #transite env based on joint_action
    
    self.step_account+=1
    self.obs_current_chache=copy.deepcopy(self.obs)
    #self.obs_onehot_current_chache=copy.deepcopy(self.obs_onehot)

    self.obs_prepare=[]
    self.obs_onehot_prepare=copy.deepcopy(self.obs_onehot)
    self.current_start_prepare = copy.deepcopy(self.current_start)
    self.current_goal_prepare  = copy.deepcopy(self.current_goal)
    # 1) first judge action_i whether available, to output !!!obs_prepare & obs_onehot_prepare!!!
    for i in range(self.agent_num):
      action_i=joint_action[i]  
      # 1) first judge action_i whether available, to output obs_prepare: 
      # if unavailable ⇢ obs_prepare.append( self.obs_old[i])
      #print("Avaible actions",self.get_avail_agent_actions(i, self.n_actions)[1])
      if action_i not in self.get_avail_agent_actions(i, self.n_actions)[1]:
        #print("This is not Avaible",i,action_i,self.get_avail_agent_actions(i, self.n_actions)[1])
        self.obs_prepare.append(self.obs_current_chache[i] )
        #self.obs_onehot_prepare[i]= self.obs_onehot[i]

      # if available ⇢ obs_prepare update by obs_i_
      else:
        #self.joint_action_old[i] = joint_action[i]
        self.current_goal_prepare[i]=joint_action[i] #update 行き先ノード when avable action is taken
        obs_i=self.obs[i]
  
        #calculate current distance
        current_goal=list(self.pos[int(action_i)])
        current_x1,current_y1=obs_i[0],obs_i[1]
        x=current_goal[0]-current_x1
        y=current_goal[1]-current_y1
        dist_to_cgoal=np.sqrt( np.square(x) + np.square(y) )# the distance to current goal

        if dist_to_cgoal>self.speed:# move on edge
            current_x1=round(current_x1+(self.speed*x/dist_to_cgoal ),2)
            current_y1=round(current_y1+(self.speed*y/dist_to_cgoal ),2)
            obs_i_= [round(current_x1,2),round(current_y1,2),obs_i[2],obs_i[3] ]
            
            # for one-hot state
            x=list(self.pos[self.current_start[i]])[0]-current_x1
            y=list(self.pos[self.current_start[i]])[1]-current_y1
            dist_to_cstart=np.sqrt( np.square(x) + np.square(y) )# the distance to current goal
            dist_to_cstart_rate= round(dist_to_cstart/(dist_to_cstart+dist_to_cgoal),2)
            
            #print("self.obs_onehot_prepare before",self.obs_onehot_prepare )
            self.obs_onehot_prepare[i]=np.zeros( ( 1,  len(list(self.G.nodes()))*2 ) )
            self.obs_onehot_prepare[i][int(action_i)]=dist_to_cstart_rate
            self.obs_onehot_prepare[i][int(self.current_start[i])]=1-dist_to_cstart_rate
            self.obs_onehot_prepare[i][int(self.goal_array[i])+ len(list(self.G.nodes()))  ] = 1 #current goal
            #print("self.obs_onehot_prepare after",self.obs_onehot_prepare )
        # arrive at node
        else:
            obs_i_ = [round(self.pos[int(action_i)][0],2),round(self.pos[int(action_i)][1],2),obs_i[2],obs_i[3] ]
            
            # for one-hot state
            self.obs_onehot_prepare[i]=np.zeros( ( 1,  len(list(self.G.nodes()))*2 ) )
            self.obs_onehot_prepare[i][int(action_i)]=1
            self.obs_onehot_prepare[i][int(self.goal_array[i])+ len(list(self.G.nodes()))  ] = 1 #current goal
            

            #print("self.obs_onehot_prepare",self.obs_onehot_prepare)

            # update current_start only when arrive at node
            self.current_start_prepare[i]=int(action_i) #update 出発ノード when　行き先ノード　has been arrived
            self.current_goal_prepare[i]=None #update 行き先ノード when it has been arrived

        self.obs_prepare.append( obs_i_ )
    
    # 2) !!!obs_prepare & obs_onehot_prepare!!! を持って、
    # second judge whether to !!! obs & obs_onehot !!! according to collision happen
    collision_flag=self.ee_env.collision_detect(self.obs_prepare)
    # happen
    if collision_flag==1:#collision
      collision_reward=-1
      self.terminated=[ False for i in range(self.agent_num)]
      info={}
      #return self.obs,[ collision_reward for i in range(self.agent_num)],self.terminated, info
      
      if self.state_repre_flag=='coordinate':
        return self.obs,[ collision_reward for i in range(self.agent_num)],self.terminated, info
      elif self.state_repre_flag=='onehot':
        print('onehot',self.obs_onehot)
        return self.obs_onehot,[ collision_reward for i in range(self.agent_num)],self.terminated, info
      elif self.state_repre_flag=='heu_onehot':
        print('heu_onehot',hrs_hot_func(self, self.obs))
        return hrs_hot_func(self, self.obs),[ collision_reward for i in range(self.agent_num)],self.terminated, info
      
      elif self.state_repre_flag=='onehot_fov':
        onehot_fov_v=neighbor_filter_obs(self,self.state_repre_flag)
        print('onehot_fov', onehot_fov_v)
        return onehot_fov_v,[ collision_reward for i in range(self.agent_num)],self.terminated, info
      
      elif self.state_repre_flag=='heu_onehot_fov':
        heu_onehot_fov_v=neighbor_filter_obs(self,self.state_repre_flag)
        print('heu_onehot_fov', heu_onehot_fov_v)
        return heu_onehot_fov_v,[ collision_reward for i in range(self.agent_num)],self.terminated, info   
      
    # not happen
    else: #non collision
      self.obs=tuple( [np.array(i) for i in self.obs_prepare])
      self.obs_onehot=copy.deepcopy(self.obs_onehot_prepare)
      self.current_start = copy.deepcopy(self.current_start_prepare)   
      self.current_goal = copy.deepcopy(self.current_goal_prepare)

    team_reward=0
    ri_array=[]
    for i in range(self.agent_num):
      ri=self.reward(i)
      team_reward+=ri
      ri_array.append(ri)
    
    if self.terminated==[ True for i in range(self.agent_num)]:
      print("!!!all reach goal!!!")
      self.reach_account=0
      info={}
    else:
      info= {}

    if self.state_repre_flag=='coordinate':
      return self.obs,ri_array,self.terminated, info
    elif self.state_repre_flag=='onehot':
      print('onehot',self.obs_onehot)
      return self.obs_onehot,ri_array,self.terminated, info
    elif self.state_repre_flag=='heu_onehot':
      print('heu_onehot',hrs_hot_func(self, self.obs))
      return hrs_hot_func(self, self.obs),ri_array,self.terminated, info
    
    elif self.state_repre_flag=='onehot_fov':
      onehot_fov_v=neighbor_filter_obs(self,self.state_repre_flag)
      print('onehot_fov', onehot_fov_v)
      return onehot_fov_v,ri_array,self.terminated, info
    elif self.state_repre_flag=='heu_onehot_fov':
      heu_onehot_fov_v=neighbor_filter_obs(self,self.state_repre_flag)
      print('heu_onehot_fov', heu_onehot_fov_v)
      return heu_onehot_fov_v,ri_array,self.terminated, info   
    
    # return self.obs,ri_array,self.terminated, info

  def reward(self,i,):
    pre_pos_agenti=[self.obs_current_chache[i][0],self.obs_current_chache[i][1]]
    pos_agenti=[self.obs[i][0],self.obs[i][1]]

    #print( pos_agenti, self.pos[self.obs[i][3]] )
    if str(pos_agenti)==str(self.pos[self.goal_array[i]]): # at goal
      if pre_pos_agenti!=pos_agenti : #first time to reach goal 
        r_i=100
        self.reach_account+=1
        self.terminated[i]=True
      else: # stop at goal
        r_i=0   
    
    else: #at a general node 
      if pre_pos_agenti==pos_agenti: # stop at a general node 
        r_i=-0.01*self.speed
      else: # just move 
        r_i=-0.01*self.speed
     
    return r_i


  def render(self, mode='human'):
    self.ee_env.plot_map_dynamic(self.visu_delay,self.obs_current_chache,
    self.obs,self.goal_array,
    self.agent_num,
    self.current_goal,
    self.reach_account,
    self.step_account,
    self.episode_account) # a must be a angle !!!list!!!
    #print('Mal Environment render')

  def close(self):
    print('Environment CLOSE')
    return None
    

